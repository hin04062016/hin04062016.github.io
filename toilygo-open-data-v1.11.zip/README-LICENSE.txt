ToilyGo v1.11 (13) - Open data database download
Published 2026-10-31 by Yu Hin Lai. Support: hinsstudio2023@gmail.com

Contains the complete machine-readable OSM-derived databases included in this release. No iOS application source code or private retailer directories are included.

OpenStreetMap data: © OpenStreetMap contributors.
https://www.openstreetmap.org/copyright
Open Database License (ODbL) 1.0:
https://opendatacommons.org/licenses/odbl/1-0/
The OSM-derived databases and ToilyGo's database adaptations are made available under ODbL 1.0. Attribution, share-alike and other license conditions apply. Individual contents retain their applicable rights. App code, trademarks, logos and Apple Maps content are not licensed by this download.

The station files also contain separately attributed government/open data fields:
- Taiwan: Ministry of Environment / Taipei City Government; Open Government Data License 1.0: https://data.gov.tw/license
- Hong Kong: MTR Corporation Limited, MTR routes, fares and barrier-free facilities; DATA.GOV.HK Terms and Conditions: https://data.gov.hk/en/terms-and-conditions
  Dataset: https://data.gov.hk/en-data/dataset/mtr-data-routes-fares-barrier-free-facilities
These source organizations own the intellectual property rights in their respective data. Neither they nor OpenStreetMap endorse ToilyGo. Each record retains source, coordinateSource and (where supplied) restroomSource/amenitiesSource/hoursSource attribution. The source labels identify original records; ToilyGo has filtered, normalized and combined selected fields. Terms for these non-OSM contents continue to apply.

Changes: selected toilets, convenience stores, malls and stations; normalized fields/coordinates; deduplicated OSM station objects; retained explicit government facility evidence; uncertain facility/access/hours values remain unknown. Store opening hours do not imply toilet availability. This is a dated snapshot, not a complete or real-time inventory. Published and fetched dates are retained within the databases.

No warranty of accuracy, completeness or current access. Use on-site/operator information to confirm availability. See manifest.json for exact file hashes and record counts.
